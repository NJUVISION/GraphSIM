% GSPBOX - Pointclouds
%
%  Generate pointclouds
%    gsp_twospirals              -  Generate two spirals
%
%  Utils
%    gsp_pointcloud              -  Load a pointcloud model and returns the set of points
%
%  For help, bug reports, suggestions etc. please send email to
%  gspbox 'dash' support 'at' groupes 'dot' epfl 'dot' ch
%
