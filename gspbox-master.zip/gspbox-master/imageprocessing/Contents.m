% GSPBOX - Image Processing
%
%  Utils
%    gsp_patch_graph              - Create a graph connecting image pixels
%
%  For help, bug reports, suggestions etc. please send email to
%  gspbox 'dash' support 'at' groupes 'dot' epfl 'dot' ch
%
