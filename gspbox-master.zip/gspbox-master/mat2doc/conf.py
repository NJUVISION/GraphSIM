plotengine = 'matlab'
author = 'Nathanael Perraudin, David Shuman, Johan Paratte'
version = "0.3.1"
versionfile = "gspbox_version"
year = "2014"

outputdir = '/tmp'

try:
    from conf_local import *
except:
    raise
